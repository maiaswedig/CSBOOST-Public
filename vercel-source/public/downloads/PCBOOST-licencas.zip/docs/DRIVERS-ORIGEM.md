# Origem dos drivers recuperados

Os arquivos abaixo foram extraídos dos recursos do PCBOOST original e continuam sem alteração no projeto. A identificação veio dos INF e dos avisos embutidos. Isso identifica o fabricante, mas não confirma por si só a licença de redistribuição do conjunto extraído.

| Componente | Evidência local | Origem oficial para obter uma cópia atual | Estado da licença recuperada |
|---|---|---|---|
| CH340/CH341 | INF declara WCH e driver 4.0.2026.02 | [WCH CH341SER](https://www.wch-ic.com/downloads/CH341SER_ZIP.html) | INF contém copyright WCH, mas não trouxe licença integral de redistribuição. |
| CP210x | INF identifica Silicon Laboratories | [Silicon Labs CP210x VCP](https://www.silabs.com/software-and-tools/usb-to-uart-bridge-vcp-drivers) | INF contém copyright do fabricante, sem licença integral no pacote recuperado. |
| FTDI | INF contém o aviso e o contrato do fabricante | [FTDI drivers e termos](https://ftdichip.com/drivers/) | O texto de licença aparece no INF preservado; consulte a versão e o tipo de driver aplicável antes de redistribuir. |
| Arduino | INF contém copyright Arduino e licença GPL v2 ou posterior | [Arduino Software](https://www.arduino.cc/en/software) | O aviso GPL está no INF. A licença do conjunto binário e dos arquivos CAT ainda precisa ser revisada. |
| Worker NVIDIA | Binário `recovered-source/PcBoost.Native.pcboost-nvidia.exe`, extraído do executável original | O binário não veio acompanhado de fonte ou endereço de origem verificável | SHA-256: `58A52D67D1DAE2E3C1B9F2ABB687C31C8656E4F8AED8713D2997BA01DA367F54`. Licença e proveniência não confirmadas. |

O build completo local mantém esses pacotes para preservar o aplicativo recuperado. A edição pública `-PublicRelease` os exclui e mantém os links para as páginas oficiais; o PCBOOST não baixa nem instala esses drivers por conta própria. O mesmo build exclui o worker NVIDIA até sua origem e licença serem comprovadas.

Esta pasta não contém um hash de referência de fabricante para cada arquivo serial nem uma validação de redistribuição para todos os itens. O hash do worker acima identifica apenas a cópia atualmente no projeto; não prova autoria nem legitimidade. A versão pública não contém esses arquivos.


## Inventário SHA-256 da cópia recuperada

Estes hashes identificam a cópia local; não comprovam licença nem substituem comparação com o fabricante. Todos os arquivos abaixo são excluídos de PublicRelease.

| Arquivo | SHA-256 |
|---|---|
| `Drivers.Arduino.arduino-org.cat` | `7641A045989CBA0E27802A60D299D67D5FFDF8B37CB4F23A345CE5B5B65F1877` |
| `Drivers.Arduino.arduino-org.inf` | `EB6D1ED883DAF79B185D1ADAEB1ED8BFC5D419016F7AA2CFC04E8A5AD315AF7B` |
| `Drivers.Arduino.arduino.cat` | `B560E4188AD3AA51F85AE699DA831775AB79AE49C9D12ECB437B27B515663C69` |
| `Drivers.Arduino.arduino.inf` | `3B7ABAC3FE17607BC6504D9254DFC702505E2A88CE8FA718EB0D6417F71CC9D4` |
| `Drivers.Arduino.arduino_gemma.cat` | `821C5893B6CFE521352D496EF53CB63212F9ACF83E8390150F0C335FA33B29EB` |
| `Drivers.Arduino.arduino_gemma.inf` | `9D85C43B41B9029A45F2AA8569811A8E320FAB36616A6E3888ADB34A66698AF5` |
| `Drivers.Arduino.genuino.cat` | `E9B25988DAADD31967D1320DFF0531558A46F3D544A3873091208211214B9BD0` |
| `Drivers.Arduino.genuino.inf` | `EB4DE6CCED98BD37138B7581D9E0073ADE228F80F082662CFC6931C295C2132E` |
| `Drivers.CH340.CH341M64.sys` | `D1F001401A28E43E20A3ED9CCFD5267A11FEF4A9846183BAB6A2CDB10ACB4237` |
| `Drivers.CH340.CH341PORTS.DLL` | `9E79736E949897B8FF8E959E2B6B67EAD2AD061A4C63F72BFA70995023EF7E05` |
| `Drivers.CH340.CH341PORTSA64.DLL` | `98707B112D079E05241298D1AB19BAC83E0A18D8334A5BC096C359A169838A0B` |
| `Drivers.CH340.CH341PT.DLL` | `222F91AAEEDA5D8348552F0EDBB9125948DBFA38DACCEFAB7CA001EFC70FFC74` |
| `Drivers.CH340.CH341PTA64.DLL` | `CB0FB42B6B3BA62AFF1999132DF9A41F3993F7F79EDE4B020048240934BF4F91` |
| `Drivers.CH340.CH341S64.sys` | `83078D87254EE4F52F08498C0458F27308C7AB857278EDA59F8EC5BFD5E1D5CE` |
| `Drivers.CH340.CH341SER.CAT` | `B5F2EF9FCDFAAC86243D47B26E77BC3378CABDEF18EBA3E04975C6403756BD28` |
| `Drivers.CH340.CH341SER.INF` | `1BBB1DFE5E311F53C2AE3928493DD884CABC12F992C7414A9509B28BF1F729DF` |
| `Drivers.CH340.CH341SER.sys` | `BD849760A396CE7E9B0BF04CE49D528DB63CAE2056A0B3187363C602C15110CF` |
| `Drivers.CP210x.arm.silabser.sys` | `92328E7293E68F67F3AE0F58D0F8EFF1B127A68A36099E883193ADA8A7F1A7F9` |
| `Drivers.CP210x.arm64.silabser.sys` | `DC1C36AA820726447D68257908AEA6FCD91989BF6955921291F6CF5157F33919` |
| `Drivers.CP210x.silabser.cat` | `8E5C5231EC368B039CFD13F7B314E46682EC06C455B25DDC544F3B410EAF0B19` |
| `Drivers.CP210x.silabser.inf` | `38E00414A04A2D525BDC61F4AE7CC12D42F90296C17BD793DFC244A2D5B58B84` |
| `Drivers.CP210x.x64.silabser.sys` | `6A870CAF98B776827F74994FF284C693C67CA14D29844FA27855EF5C1AF07E05` |
| `Drivers.CP210x.x86.silabser.sys` | `DEF7E693D86B6AD158F000B53B301BDE202DD284E6F5C4271517F6A8DD35A065` |
| `Drivers.FTDI.amd64.ftbusui.dll` | `793608C0DEF83F2D4070274D12E68444EC464E7129CE813BA3EC98BFF4F14FFA` |
| `Drivers.FTDI.amd64.ftcserco.dll` | `97ADE3F76A3A89121360B6C6A68D110B4C6F4BFD749695A552F87D117C0C851A` |
| `Drivers.FTDI.amd64.FTD2XX64.dll` | `52260F7751FBC545573CA29E4C27BFE005A97A98E9A7E5C28B77735568D6C5D5` |
| `Drivers.FTDI.amd64.ftdibus.sys` | `FC2CDDED48974852BE35D7C8BDE565514CFEC5F224AB3B85642B36D68A03BB5C` |
| `Drivers.FTDI.amd64.ftlang.dll` | `4FB0E49C8B4FABEEAF6B84021504D5FF8FD207683272DB74D178BE72228E7232` |
| `Drivers.FTDI.amd64.ftser2k.sys` | `404DCB68B1FBF686388BBAD3BCBCFFCDA2662D436F45716690B452E9FF909F8E` |
| `Drivers.FTDI.amd64.ftserui2.dll` | `407B7F5E2EEDD1E1BE754DF66EB249DFE674F8FE0A67D1A0D5942F3CCC6B3BEB` |
| `Drivers.FTDI.ftdibus.cat` | `B5376AE984033E0A503B793E31121F3208453A505BF9AC150F466690504782EF` |
| `Drivers.FTDI.ftdibus.inf` | `9C8C5F39953965E7AC205826346898F974BD0916D487528C5D7925BA122B98A2` |
| `Drivers.FTDI.ftdiport.cat` | `134B692A4AF2148D60C6E1874FA6E6AF12507B3C5DC64A2A568E44EC1D64FE9F` |
| `Drivers.FTDI.ftdiport.inf` | `EF52D16FC306BBAAB384C767E5B8C4C7BABCF622099FDA9CB8D9D72651760209` |
| `Drivers.FTDI.i386.ftbusui.dll` | `DC2E9D5E3749B21D34D168BA9CCEA38F5F311D3F77D2E8E83FB5560F9F2B961A` |
| `Drivers.FTDI.i386.ftcserco.dll` | `F50EEB61F18D94BB9F51E5657A473E3C212C964B8D103A5D717DF98614F48A42` |
| `Drivers.FTDI.i386.ftd2xx.dll` | `1BD207779A612B6A37D0EFEF7B623F6F72966BECF059DE4008E801841C12ABEC` |
| `Drivers.FTDI.i386.ftdibus.sys` | `85822DD41D6908A0AC5AA3C235BAECF82698703AA8DFC4475BAAACEF71ED6E2A` |
| `Drivers.FTDI.i386.ftlang.dll` | `C3FBE8B57BD1DE5CED84126C094F1CBD0EBA145B6EC4679EBBA453DDA6E785CA` |
| `Drivers.FTDI.i386.ftser2k.sys` | `ADF1E11688612E0456838A838FEE90597610BF1F035DCDAA7F9C1B046B612FC7` |
| `Drivers.FTDI.i386.ftserui2.dll` | `87B0FE655B5B81105D974131649BE0821853B182CA8350B2F1A40C89947D0DFC` |
