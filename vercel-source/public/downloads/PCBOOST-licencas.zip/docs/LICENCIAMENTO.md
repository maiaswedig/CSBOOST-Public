# Escopo da licença e condição de distribuição

Em 30/10/2026, o usuário declarou ser autor de todo o código PCBOOST 0.1.2 recuperado e deter os direitos sobre essa base. A distribuição do PCBOOST é preparada com base nessa declaração. O aviso MIT de RESET EXPLODE 0.16.0 e as licenças de dependências identificadas continuam preservados nos arquivos indicados em `NOTICE.md`.

Esta declaração de autoria vem do próprio usuário do projeto e não foi verificada por documento externo. Os componentes de terceiros continuam limitados às licenças e avisos próprios identificados. A edição `PublicRelease` exclui drivers seriais e o worker NVIDIA, cuja redistribuição não foi confirmada. O CI e o build local verificam aspectos técnicos; não substituem os avisos e licenças que acompanham o pacote.
