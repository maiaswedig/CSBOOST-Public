# Checklist de distribuição

## Histórico — versão pública 0.1.33.0 — 30/10/2026

- [x] Build `PublicRelease` sem drivers seriais, worker NVIDIA ou fontes embutidas.
- [x] Direitos da base PCBOOST 0.1.2 declarados pelo usuário; avisos do RESET EXPLODE e licenças das dependências preservados.
- [x] ZIP portátil publicado na página pública do [CSBOOST](https://csboost.vercel.app/#pcboost).
- [x] O site serviu as oito partes com HTTP 200; o ZIP remontado tem 89.853.513 bytes e SHA-256 `AFD28AE1ABF7C95FFDA09C6AF4754A7D07B7CAADE576883A57C406546BD689F0`.
- [x] Arquivo `.sha256` publicado e status de produção do Vercel `success`.
- [x] ZIP extraído localmente; executável e assinatura conferidos neste PC.

## Versão pública atual 0.1.40.0 — 31/10/2026

- [x] Suíte local `atualizar.ps1 -Action Check` concluída; 29 verificações centrais e bateria de interface passaram.
- [x] Build `PublicRelease` sem drivers seriais, worker NVIDIA ou fontes embutidas.
- [x] Executável 0.1.40.0 assinado e válido neste perfil do Windows; tamanho 95.856.232 bytes, SHA-256 `C60022E2512FA53064AF4D2F6F8AC2011EFA155390EA089EC7419AD93305E22A`.
- [x] ZIP portátil com `PCBOOST.exe` apenas; 89.822.901 bytes, SHA-256 `6525D0179A774AB8C65F6A007DFE6593010B7401C59BF6EA0D7FA33681DCAABB`.
- [x] Publicado junto ao CSBOOST pelo [PR #3](https://github.com/maiaswedig/CSBOOST-Public/pull/3); deploy Vercel de produção `READY`, commit `d2254623e8e97635547656dc6c5b0789ee63b63b`.
- [x] Página, manifesto sem cache, sidecar e oito partes verificadas publicamente; o ZIP reconstruído tem o tamanho e hash esperados.
- [x] App mostra aviso modal em primeiro plano uma vez por nova versão e tem botão manual **Atualizar**. A confirmação abre a página oficial; instalação do ZIP permanece manual.

## Limites e validações pendentes da 0.1.40.0

- [ ] Testar a instalação e inicialização em outro PC Windows 11 x64. O botão não foi acionado em navegador visual; as oito partes públicas foram baixadas, reunidas e verificadas.
- [ ] Conferir GPUs NVIDIA/AMD/Intel, notebook Modern Standby, múltiplos monitores, escala 125–200%, alto contraste e leitor de tela.
- [ ] A assinatura é autoassinada e confiável apenas neste perfil do Windows. Em outros PCs pode aparecer publicador desconhecido ou SmartScreen; não há reputação SmartScreen.
- [ ] Testar em máquina Windows 10 compatível: instalação, inicialização, navegação e restauração. O build local bloqueia opções exclusivas do Windows 11, mas a validação real ainda não ocorreu. A tabela do .NET 10 lista Windows 10 21H2, 1809 e 1607 nas edições Enterprise/LTSC.

## Histórico — candidato local 0.1.34 — Windows 11 x64

- [x] Suíte completa e checagem de recursos do `PublicRelease` aprovadas.
- [x] ZIP portátil montado, assinatura do executável conferida neste PC e SHA-256 do ZIP/conteúdo verificado.
- [ ] Nunca publicado; substituído pela versão 0.1.40.0. Não usar para distribuição.

O instalador x64 `artifacts/installer/PCBOOST-Setup-0.1.10.0.exe` está desatualizado e não deve ser usado com a versão pública atual. O pacote público atual é ZIP portátil. Os drivers seriais e o worker NVIDIA permanecem fora do pacote; o código completo continua no projeto local.

Consulte a [revisão da etapa 8](etapa-8-distribuicao.md) para detalhes do site, pacote e verificação do hash.
Consulte também a [Etapa 9 — Windows 10](etapa-9-windows-10.md); não publique o build local como compatível com Windows 10 antes de concluir o teste real.
O escopo seguinte está na [Etapa 10 — homologação e publicação](etapa-10-homologacao-publicacao.md).
