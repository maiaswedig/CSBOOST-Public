# Dependências da reconstrução

Inventário obtido de `project.assets.json` após restaurar o projeto Windows x64. Inclui dependências transitivas e pacotes que trazem ativos de outras plataformas; o publish win-x64 seleciona somente os ativos necessários a esse alvo. Os arquivos de licença fornecidos pelos pacotes estão em `docs/licenses/`.

| Pacote | Versão | Licença declarada |
|---|---|---|
| BlackSharp.Core | 1.0.7 | MPL-2.0 |
| DiskInfoToolkit | 1.1.2 | MPL-2.0 |
| HidSharp | 2.6.4 | Arquivo: LICENSE.txt |
| LibreHardwareMonitorLib | 0.9.6 | MPL-2.0 |
| Microsoft.Diagnostics.NETCore.Client | 0.2.661903 | MIT |
| Microsoft.Diagnostics.Tracing.TraceEvent | 4.0.0 | MIT |
| Microsoft.Extensions.DependencyInjection.Abstractions | 8.0.2 | MIT |
| Microsoft.Extensions.Logging.Abstractions | 8.0.3 | MIT |
| Microsoft.NET.ILLink.Tasks | 10.0.13 | MIT |
| Mono.Posix.NETStandard | 1.0.0 | https://go.microsoft.com/fwlink/?linkid=869050 |
| RAMSPDToolkit-NDD | 1.4.2 | MPL-2.0 |
| runtime.android-arm.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.android-arm64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.android-x64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.android-x86.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-arm.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-arm64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-bionic-arm64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-bionic-x64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-musl-arm.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-musl-arm64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-musl-x64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.linux-x64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.maccatalyst-arm64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.maccatalyst-x64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.osx-arm64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| runtime.osx-x64.runtime.native.System.IO.Ports | 10.0.3 | MIT |
| SharpGen.Runtime.COM | 2.4.2-beta | MIT |
| SharpGen.Runtime | 2.4.2-beta | MIT |
| System.IO.FileSystem.AccessControl | 5.0.0 | MIT |
| System.IO.Ports | 10.0.3 | MIT |
| System.Management | 10.0.14 | MIT |
| System.Reflection.TypeExtensions | 4.7.0 | MIT |
| Vortice.D3DCompiler | 3.8.3 | MIT |
| Vortice.Direct3D11 | 3.8.3 | MIT |
| Vortice.Direct3D12 | 3.8.3 | MIT |
| Vortice.DirectX | 3.8.3 | MIT |
| Vortice.Dxc.Native | 1.0.5 | Arquivo: LICENSE-MS.txt |
| Vortice.Dxc | 3.8.3 | MIT |
| Vortice.DXGI | 3.8.3 | MIT |
| Vortice.Mathematics | 2.1.0 | MIT |

O runtime .NET autocontido tem avisos em `docs/licenses/dotnet/`. Os drivers seriais e o módulo nativo NVIDIA recuperados do executável são componentes separados deste inventário; consulte `docs/DRIVERS-ORIGEM.md` e `NOTICE.md` para origem e limites de redistribuição.
