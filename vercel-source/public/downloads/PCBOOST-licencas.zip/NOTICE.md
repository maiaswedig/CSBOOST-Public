# PCBOOST — créditos, licenças e componentes

Em 30/10/2026, o usuário declarou ter criado todo o código PCBOOST 0.1.2 e deter os direitos da base recuperada. A distribuição se baseia nessa declaração, que não foi verificada por documento externo. Foram também identificados trechos relacionados ao RESET EXPLODE 0.16.0; o aviso MIT da revisão consultada está em [`docs/LICENSE-ResetExplode.txt`](docs/LICENSE-ResetExplode.txt) e continua preservado.

A licença MIT em `LICENSE` e o aviso MIT de RESET EXPLODE são distribuídos com o programa. Bibliotecas e dependências mantêm as licenças listadas em [`docs/DEPENDENCIAS.md`](docs/DEPENDENCIAS.md) e [`docs/licenses/`](docs/licenses/). Ver [`docs/LICENCIAMENTO.md`](docs/LICENCIAMENTO.md) para a declaração de autoria da base.

O CSBOOST serviu apenas como referência de identidade visual; esta pasta não contém código-fonte do CSBOOST. Não há afiliação ou endosso entre os projetos.

Bibliotecas NuGet e textos de licença fornecidos por seus pacotes estão inventariados em [`docs/DEPENDENCIAS.md`](docs/DEPENDENCIAS.md) e [`docs/licenses/`](docs/licenses/). O diretório `docs/licenses/dotnet/` contém os avisos do runtime autocontido. A lista de pacotes documenta a restauração de build; o publish win-x64 seleciona apenas os ativos dessa plataforma.

Os drivers seriais de WCH, Silicon Labs, FTDI e Arduino e o worker nativo NVIDIA permanecem no build completo local, recuperados do aplicativo original. A edição pública `-PublicRelease` exclui esses arquivos porque não há comprovantes completos de redistribuição nem código-fonte/proveniência do worker NVIDIA. Detalhes e hashes estão em [`docs/DRIVERS-ORIGEM.md`](docs/DRIVERS-ORIGEM.md).

Integrações opcionais com iCUE, OpenRGB, Razer, NVIDIA, WinGet e HowManyFPS dependem de instalação, permissões, hardware e termos próprios. O estado de distribuição e os bloqueios conhecidos constam em [`docs/RELEASE-CHECKLIST.md`](docs/RELEASE-CHECKLIST.md).
